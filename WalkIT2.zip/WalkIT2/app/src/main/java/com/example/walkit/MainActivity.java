package com.example.walkit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    //Initializing UI elements
    EditText weight,distance,steps;
    Button power_walk,casual_walk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Configuration of the UI elements
        weight = findViewById(R.id.Kg);
        distance = findViewById(R.id.Km);
        steps = findViewById(R.id.Steps);
        power_walk = findViewById(R.id.Power);
        casual_walk = findViewById(R.id.Casual);

        createNotificationChannel();

        //Setting the Click Listener for the casual walk button
        casual_walk.setOnClickListener(v ->{

            //Get values from the EditText fields
            String weightStr = weight.getText().toString();
            String distanceStr = distance.getText().toString();
            String stepsStr = steps.getText().toString();

            if(weightStr.isEmpty() || distanceStr.isEmpty()|| stepsStr.isEmpty()){
                showDialog("All fields are mandatory!");
                return;
            }

            // Convert string values to double.
            double kg,step,km;

            kg=step=km=0;
            
            if(step!=(int)step){
                showDialog("Steps must be an Integer!");
                return;
            }

            step = Integer.parseInt(stepsStr);

            try{
                kg = Double.parseDouble(weightStr);
                km = Double.parseDouble(distanceStr);
                // step is an integer!
            } catch (NumberFormatException e) {
                // not an integer!
                showDialog("Weight and Distance must be Numbers!");
                return;
            }

            if(km==0){
                showDialog("Km can not be zero!");
                return;
            }

            //Declaring the Coefficient of the Casual Walking formula
            double coCasual = 0.416;

            //Calculating Casual Walking Calories
            double calories = coCasual*kg*(step/km);

            //Formatting the result
            String displayCalories = String.format("%.2f", calories); // Round the result
            String finalDisplayCalories = "The Calories you burned per step are: "+displayCalories;

            //Notification
            //Display category in notification
            NotificationCompat.Builder mBuilder =  new NotificationCompat.Builder(getApplicationContext(), "test")
                    .setSmallIcon(R.drawable.ic_launcher_background)
                    .setContentTitle("Calories Category")
                    .setContentText(findCalories(calories)+" ("+finalDisplayCalories+")")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            // notificationID allows you to update the notification later on.
            if (mNotificationManager != null) {
                mNotificationManager.notify(10, mBuilder.build());
            }
        });


        //Setting the Click Listener for the power walk button
          power_walk.setOnClickListener(v -> {

            //Get values from the EditText fields
              String weightStr = weight.getText().toString();
              String distanceStr = distance.getText().toString();
              String stepsStr = steps.getText().toString();

            if(weightStr.isEmpty() || distanceStr.isEmpty()|| stepsStr.isEmpty()){
                showDialog("All fields are mandatory!");
                return;
            }

            // Convert string values to double.
               double kg,step,km;

               kg=step=km=0;

              if(step!=(int)step){
                  showDialog("Steps must be an Integer!");
                  return;
              }

              step = Integer.parseInt(stepsStr);

            try{
                kg = Double.parseDouble(weightStr);
                km = Double.parseDouble(distanceStr);
                // is an integer!
            } catch (NumberFormatException e) {
                // not an integer!
                showDialog("Weight and Distance must be Numbers!");
                return;
            }

              if(km==0){
                  showDialog("Km can not be zero!");
                  return;
              }

            //Declaring the Coefficient of the Power Walking formula
              double coPower = 0.365;

                //Calculating Casual Walking Calories
                double calories = coPower * kg * (step / km);


                //Formatting the result
                String displayCalories = String.format("%.2f", calories); // Round the result
                String finalDisplayCalories = "The Calories you burned per step are : " + displayCalories;


                //Notification
                //Display category in notification
                NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(getApplicationContext(), "test")
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentTitle("Calories Category")
                        .setContentText(findCalories(calories) + " (" + finalDisplayCalories + ")")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                // notificationID allows you to update the notification later on.
                if (mNotificationManager != null) {
                    mNotificationManager.notify(10, mBuilder.build());
                }

        });


    }

    private String findCalories(double calories){
        return "";

    }

    private void showDialog(String message){

        //Alert Dialog
        //Display category in alert dialog
        AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
        builder1.setMessage(message);
        builder1.setCancelable(false);

        builder1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();

                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "test1";
            String description = "test2";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("test", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }


}